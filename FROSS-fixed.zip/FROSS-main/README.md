# FROSS

Русскоязычный экспериментальный ассистент на собственном decoder-only Transformer (**FROSS Transformer 1.6**), обученном с нуля. Сайт с чатом, историей диалогов в Firebase, веб-поиском и Python-сервисом генерации.

## Модель

| Параметр | Значение |
|---|---|
| Архитектура | decoder-only Transformer, 18 слоёв, 8 attention heads, embedding 520 |
| Параметры | около 64,8 млн |
| Токенизатор | SentencePiece Unigram, 8 000 токенов |
| Контекст | 4 096 токенов |
| План обучения | 100 000 шагов (этапы 25 000 / 50 000 / 75 000 / 100 000) |

Модель стартует со случайных весов, не использует предобученные чекпоинты и не вызывает сторонние LLM API при генерации. Поиск в интернете добавляет контекст к запросу, но веса не меняет. Модель маленькая и экспериментальная: качество ответов напрямую зависит от размера и разнообразия корпуса.

## Структура репозитория

- `public/chat.html` — веб-интерфейс чата (`index.html` только перенаправляет на него)
- `public/training.html` — страница обучения
- `public/firebase-config.js` — конфигурация Firebase Web App
- `worker.js` — Cloudflare Worker: маршрутизация, поиск, проверки лимитов
- `fross_transformer.py` — Transformer и токенизатор
- `services/python-brain/` — HTTP-сервис генерации (Docker, Render)
- `data/` — обучающие корпуса (`fross_corpus.jsonl`, `fross_teacher_corpus.jsonl`)
- `training/windows/` — [локальное обучение на Windows](training/windows/README_RU.md)
- `training/distillation/` — [подготовка корпуса и дистилляция](training/distillation/README_RU.md)
- `memory/` — [общая база знаний](memory/README.md)
- `tests/` — тесты Transformer, дистилляции и маршрутов сервиса
- `firestore.rules`, [FIRESTORE_RULES.md](FIRESTORE_RULES.md) — правила безопасности Firestore
- [SETUP.md](SETUP.md) — пошаговая настройка, [FROSS_CHARACTER.md](FROSS_CHARACTER.md) — характер и правила безопасности

## Быстрый старт

1. Следуй [SETUP.md](SETUP.md): Firebase (Google-вход, Firestore, правила), Cloudflare Worker, Python-сервис на Render, секрет `FROSS_BRAIN_SERVICE_TOKEN`.
2. Впиши значения Firebase Web App в `public/firebase-config.js`.
3. Для обучения на своём ПК запусти по порядку `training/windows/START_TRAIN_25000.bat`, затем `CONTINUE_TO_50000.bat`, `CONTINUE_TO_75000.bat`, `CONTINUE_TO_100000.bat`. Проверка: `CHECK_TRAINING.bat`.
4. Готовый компактный файл `fross-transformer-1.6-64m-int8.pt` загружается в **Настройки → Загрузить модель**.

## Лимиты

- Одно сообщение пользователя: до 30 000 символов.
- Один ответ FROSS: до 50 000 символов.
- В активный контекст отправляются последние пять реплик пользователя со связанными ответами.
- Чат хранит примерно 1 000 000 токенов (оценка: один токен на три символа), затем нужен новый чат.

## Тесты

```bash
pip install -r requirements.txt
python -m unittest discover -s tests -v
```

Дополнительно CI проверяет синтаксис `worker.js` и встроенного скрипта `public/chat.html`, конфигурацию Wrangler и сборку корпуса.

## Безопасность

Не отправляй в чат пароли, токены и приватные ключи: недавний текст диалога передаётся в настроенный Python-сервис. Не храни чаты, пароли, токены и личные данные в публичной базе знаний на GitHub. `FROSS_GITHUB_TOKEN` нужен только для публикации общей базы знаний, не для обучения.
