#!/usr/bin/env python3
"""FROSS Transformer Brain 1.6: a 64M decoder-only language model.

No third-party pretrained LLM or hosted LLM API is used. A SentencePiece Unigram tokenizer
and new token embeddings are learned from the repository corpus. Optionally, compatible
decoder blocks can be initialized from the project's own Brain 1.4 checkpoint.
This is an educational, deliberately small model; its quality is bounded by its data
and compute budget. Install PyTorch CPU wheels to train or run it.
"""
from __future__ import annotations

import argparse
import shutil
import hashlib
from collections import Counter
import json
import math
import os
from pathlib import Path
import random
import re
import string
from typing import Any

import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

VERSION = "FROSS Transformer 1.6"


def _preferred_device() -> torch.device:
    """Use CUDA only when the installed PyTorch build can actually access it."""
    requested = os.environ.get("FROSS_DEVICE", "auto").strip().lower()
    if requested == "cpu":
        return torch.device("cpu")
    if requested in {"cuda", "gpu"}:
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")

def configure_runtime_threads() -> int:
    """Limit PyTorch CPU thread pools for small containers and shared CPU quotas."""
    try:
        requested = int(os.environ.get("FROSS_TORCH_THREADS", "1"))
    except (TypeError, ValueError):
        requested = 1
    thread_count = max(1, min(2, requested))
    try:
        torch.set_num_threads(thread_count)
    except RuntimeError:
        # PyTorch may reject changes after parallel work has already started.
        pass
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        # This can only be set before PyTorch starts inter-op work.
        pass
    return thread_count
PAD_ID, UNK_ID, BOS_ID, EOS_ID = 0, 1, 2, 3
SPECIAL_TOKENS = ("<pad>", "<unk>", "<bos>", "<eos>")
# Keep the response prefix identical in training examples and generation prompts.
RESPONSE_PREFIX = "FROSS: "
BASE_CHARS = "".join(dict.fromkeys(
    string.ascii_letters + string.digits + string.punctuation +
    " \n\r\t" +
    "абвгдеёжзийклмнопрстуфхцчшщъыьэюя" +
    "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ" +
    "іІїЇєЄґҐ" +
    "—–…«»„“”‘’№°·•→←✓✗≤≥≈"
))
DEFAULT_CORPUS = Path(__file__).with_name("data") / "fross_corpus.jsonl"
DEFAULT_CHECKPOINT = Path(__file__).with_name("fross-transformer.pt")
DEFAULT_UPLOAD_CHECKPOINT = Path(__file__).with_name("fross-transformer-upload.pt")
MAX_GENERATION_TOKENS = 5000

# Brain 1.6: 8K vocabulary, 4K context and a wider/deeper decoder.
# With tied embeddings this profile has 64,819,040 trainable parameters.
DEFAULT_CONFIG = {
    "block_size": 4096,
    "n_embd": 520,
    "n_head": 8,
    "n_layer": 18,
    "dropout": 0.08,
    "gradient_checkpointing": True,
}


_PRETOKEN_PATTERN = re.compile(r"\s+|[^\W_]+|_+|[^\w\s]+", flags=re.UNICODE)


class TrainingCancelled(Exception):
    """Raised when a training stage is cancelled at a safe boundary."""


class BPETokenizer:
    """BPE tokenizer trained on word/whitespace/punctuation pieces.

    New checkpoints use pretokenized=True so BPE never merges across word boundaries.
    Older checkpoints omit that flag and retain their original character-stream encoding.
    """

    def __init__(
        self,
        base_chars: str = BASE_CHARS,
        merges: list[tuple[int, int]] | None = None,
        pretokenized: bool = False,
        max_piece_chars: int = 24,
    ):
        self.base_chars = "".join(dict.fromkeys(base_chars))
        self.char_to_id = {char: index + 4 for index, char in enumerate(self.base_chars)}
        self.merges: list[tuple[int, int]] = []
        self.pieces = list(SPECIAL_TOKENS) + list(self.base_chars)
        self.pretokenized = bool(pretokenized)
        self.max_piece_chars = max(2, int(max_piece_chars))
        for left, right in (merges or []):
            left, right = int(left), int(right)
            if left < 0 or right < 0 or left >= len(self.pieces) or right >= len(self.pieces):
                raise ValueError("Invalid BPE merge in tokenizer checkpoint.")
            self.merges.append((left, right))
            self.pieces.append(self.pieces[left] + self.pieces[right])

    @property
    def vocab_size(self) -> int:
        return len(self.pieces)

    @classmethod
    def train(
        cls,
        texts: list[str],
        merge_count: int | None = None,
        min_frequency: int | None = None,
        target_vocab_size: int | None = None,
        max_piece_chars: int = 24,
        progress_callback: Any = None,
        stop_callback: Any = None,
    ) -> "BPETokenizer":
        """Train a weighted BPE vocabulary, optionally targeting an exact vocabulary size."""
        # Preserve every Unicode character present in the training text as a
        # base token before BPE merges. This matters for scripts such as Chinese
        # that are not in the small hand-written Latin/Cyrillic fallback alphabet.
        corpus_characters = "".join(str(text) for text in texts)
        base_chars = "".join(dict.fromkeys(BASE_CHARS + corpus_characters))
        tokenizer = cls(base_chars=base_chars, pretokenized=True, max_piece_chars=max_piece_chars)
        base_vocab_size = len(tokenizer.pieces)
        if target_vocab_size is not None:
            target_vocab_size = int(target_vocab_size)
            if target_vocab_size < base_vocab_size:
                raise ValueError(
                    f"target_vocab_size must be at least {base_vocab_size} for the base character set"
                )
        if merge_count is None:
            merge_count = (
                max(0, target_vocab_size - base_vocab_size)
                if target_vocab_size is not None else 384
            )
        merge_count = max(0, int(merge_count))
        threshold = max(1, int(min_frequency if min_frequency is not None else (
            1 if target_vocab_size is not None else 2
        )))

        # Count distinct pre-tokenized word-like pieces. We weight pair counts by
        # corpus frequency, so repeated words influence BPE without repeatedly
        # scanning identical character sequences.
        segment_counts: Counter[str] = Counter()
        for text in texts:
            if stop_callback is not None and stop_callback():
                raise TrainingCancelled("Training cancelled while reading the tokenizer corpus.")
            segment_counts.update(_PRETOKEN_PATTERN.findall(str(text)))

        # Recomputing every pair over every unique word for thousands of BPE
        # merges is expensive on small hosted CPUs. Keep the most frequent
        # segments for merge learning while retaining all corpus characters
        # above, so rare words still encode losslessly as character tokens.
        # This bounds first-run tokenizer preparation without reducing vocab size.
        max_bpe_segments = 3072
        if merge_count >= 1000 and len(segment_counts) > max_bpe_segments:
            segment_counts = Counter(dict(segment_counts.most_common(max_bpe_segments)))

        sequences: list[tuple[list[int], int]] = []
        for segment, frequency in segment_counts.items():
            sequence = [tokenizer.char_to_id.get(char, UNK_ID) for char in segment]
            if sequence:
                sequences.append((sequence, int(frequency)))

        pieces = list(tokenizer.pieces)
        learned: list[tuple[int, int]] = []
        progress_interval = max(1, merge_count // 100)
        last_reported_merge = -1

        def report_tokenizer_progress(completed_merges: int) -> None:
            if progress_callback is None:
                return
            try:
                progress_callback({
                    "phase": "tokenizer",
                    "preparation_step": completed_merges,
                    "preparation_total": merge_count,
                    "vocab_size": len(pieces),
                })
            except Exception:
                pass

        report_tokenizer_progress(0)
        completed_merges = 0
        for merge_index in range(merge_count):
            if stop_callback is not None and stop_callback():
                raise TrainingCancelled("Training cancelled while building the BPE vocabulary.")
            counts: Counter[tuple[int, int]] = Counter()
            for sequence, weight in sequences:
                for pair in zip(sequence, sequence[1:]):
                    left, right = pair
                    # Do not create trainable tokens that embed the literal <unk> marker.
                    if left == UNK_ID or right == UNK_ID:
                        continue
                    if len(pieces[left]) + len(pieces[right]) <= tokenizer.max_piece_chars:
                        counts[pair] += weight
            if not counts:
                break
            pair, frequency = counts.most_common(1)[0]
            if frequency < threshold:
                break

            left, right = pair
            new_id = len(pieces)
            learned.append(pair)
            pieces.append(pieces[left] + pieces[right])
            completed_merges = merge_index + 1
            if (
                completed_merges == 1
                or completed_merges % progress_interval == 0
                or completed_merges == merge_count
            ):
                report_tokenizer_progress(completed_merges)
                last_reported_merge = completed_merges
            merged_sequences: list[tuple[list[int], int]] = []
            for sequence, weight in sequences:
                result: list[int] = []
                index = 0
                while index < len(sequence):
                    if index + 1 < len(sequence) and (sequence[index], sequence[index + 1]) == pair:
                        result.append(new_id)
                        index += 2
                    else:
                        result.append(sequence[index])
                        index += 1
                merged_sequences.append((result, weight))
            sequences = merged_sequences

        if completed_merges != last_reported_merge:
            report_tokenizer_progress(completed_merges)

        return cls(
            tokenizer.base_chars,
            learned,
            pretokenized=True,
            max_piece_chars=max_piece_chars,
        )

    def encode(self, text: str) -> list[int]:
        raw = str(text)
        if not self.pretokenized:
            # Backward compatibility for checkpoints trained before Brain 1.4.
            sequence = [self.char_to_id.get(char, UNK_ID) for char in raw]
            for merge_index, pair in enumerate(self.merges):
                new_id = 4 + len(self.base_chars) + merge_index
                result: list[int] = []
                index = 0
                while index < len(sequence):
                    if index + 1 < len(sequence) and (sequence[index], sequence[index + 1]) == pair:
                        result.append(new_id)
                        index += 2
                    else:
                        result.append(sequence[index])
                        index += 1
                sequence = result
            return sequence

        encoded: list[int] = []
        for segment in _PRETOKEN_PATTERN.findall(raw):
            sequence = [self.char_to_id.get(char, UNK_ID) for char in segment]
            for merge_index, pair in enumerate(self.merges):
                new_id = 4 + len(self.base_chars) + merge_index
                result = []
                index = 0
                while index < len(sequence):
                    if index + 1 < len(sequence) and (sequence[index], sequence[index + 1]) == pair:
                        result.append(new_id)
                        index += 2
                    else:
                        result.append(sequence[index])
                        index += 1
                sequence = result
            encoded.extend(sequence)
        return encoded

    def decode(self, token_ids: list[int], stop_at_eos: bool = True) -> str:
        parts: list[str] = []
        for token_id in token_ids:
            token_id = int(token_id)
            if token_id == EOS_ID and stop_at_eos:
                break
            if token_id < 4 or token_id >= len(self.pieces):
                continue
            parts.append(self.pieces[token_id])
        return "".join(parts)

    def to_dict(self) -> dict[str, Any]:
        return {
            "base_chars": self.base_chars,
            "merges": [list(pair) for pair in self.merges],
            "pretokenized": self.pretokenized,
            "max_piece_chars": self.max_piece_chars,
        }

class SentencePieceTokenizer:
    """SentencePiece Unigram tokenizer; serialized model is embedded in the checkpoint."""

    def __init__(self, model_proto_b64: str):
        import base64
        import sentencepiece as spm
        if not isinstance(model_proto_b64, str) or not model_proto_b64:
            raise ValueError("SentencePiece checkpoint is missing its serialized model.")
        self.model_proto_b64 = model_proto_b64
        self.processor = spm.SentencePieceProcessor()
        if not self.processor.LoadFromSerializedProto(base64.b64decode(model_proto_b64)):
            raise ValueError("Could not load the SentencePiece model.")
        ids = (self.processor.pad_id(), self.processor.unk_id(), self.processor.bos_id(), self.processor.eos_id())
        if ids != (PAD_ID, UNK_ID, BOS_ID, EOS_ID):
            raise ValueError("SentencePiece special-token IDs do not match FROSS.")

    @property
    def vocab_size(self) -> int:
        return int(self.processor.get_piece_size())

    @classmethod
    def train(cls, texts: list[str], target_vocab_size: int = 8000,
              progress_callback: Any = None, stop_callback: Any = None) -> "SentencePieceTokenizer":
        import base64
        import subprocess
        import sys
        import tempfile
        import time
        from pathlib import Path
        target_vocab_size = int(target_vocab_size)
        # SentencePiece byte fallback reserves 256 byte pieces plus four
        # FROSS special tokens. Smaller vocabularies are valid for unit tests.
        if target_vocab_size < 260:
            raise ValueError("SentencePiece byte-fallback vocabulary must be at least 260 tokens.")
        if stop_callback is not None and stop_callback():
            raise TrainingCancelled("Training cancelled before SentencePiece preparation.")
        def report(done: int) -> None:
            if progress_callback is not None:
                try:
                    progress_callback({"phase": "tokenizer_native", "preparation_step": done,
                                       "preparation_total": 1, "vocab_size": None if done == 0 else target_vocab_size})
                except Exception:
                    pass
        report(0)
        with tempfile.TemporaryDirectory(prefix="fross-spm-") as folder:
            root = Path(folder)
            corpus_path, prefix = root / "corpus.txt", root / "fross-unigram"
            with corpus_path.open("w", encoding="utf-8", newline="\n") as handle:
                for item in texts:
                    value = str(item).replace("\x00", " ").strip()
                    if value:
                        handle.write(value.replace("\n", " ") + "\n")
            if corpus_path.stat().st_size == 0:
                raise ValueError("SentencePiece training corpus is empty.")
            trainer = (
                "import sentencepiece as s,sys; "
                "s.SentencePieceTrainer.train(input=sys.argv[1],model_prefix=sys.argv[2],"
                "model_type='unigram',vocab_size=int(sys.argv[3]),character_coverage=1.0,"
                "byte_fallback=True,pad_id=0,unk_id=1,bos_id=2,eos_id=3,hard_vocab_limit=False,"
                "num_threads=1,shuffle_input_sentence=False,input_sentence_size=0,"
                "max_sentence_length=8192,minloglevel=2)"
            )
            log_path = root / "sentencepiece.log"
            with log_path.open("w", encoding="utf-8") as log_handle:
                process = subprocess.Popen(
                    [sys.executable, "-c", trainer, str(corpus_path), str(prefix), str(target_vocab_size)],
                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=log_handle,
                )
                while process.poll() is None:
                    if stop_callback is not None and stop_callback():
                        process.terminate()
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait()
                        raise TrainingCancelled("Training cancelled during native SentencePiece vocabulary training.")
                    time.sleep(0.2)
            if process.returncode != 0:
                details = log_path.read_text(encoding="utf-8", errors="replace")[-3000:]
                raise RuntimeError(
                    "Native SentencePiece Unigram training failed (exit "
                    + str(process.returncode) + "): " + details.strip()
                )
            if stop_callback is not None and stop_callback():
                raise TrainingCancelled("Training cancelled after SentencePiece vocabulary training.")
            model_proto = prefix.with_suffix(".model").read_bytes()
            report(1)
            return cls(base64.b64encode(model_proto).decode("ascii"))

    def encode(self, text: str) -> list[int]:
        return [int(value) for value in self.processor.encode(str(text), out_type=int)]

    def decode(self, token_ids: list[int], stop_at_eos: bool = True) -> str:
        values = []
        for token_id in token_ids:
            value = int(token_id)
            if value == EOS_ID and stop_at_eos:
                break
            if 0 <= value < self.vocab_size and value not in (PAD_ID, BOS_ID):
                values.append(value)
        return self.processor.decode(values)

    def to_dict(self) -> dict[str, Any]:
        return {"model_proto_b64": self.model_proto_b64}


def _causal_attention_query_chunk(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    key_positions: torch.Tensor,
    query_positions: torch.Tensor,
    head_size: int,
    dropout_probability: float,
    training: bool,
) -> torch.Tensor:
    """Compute one causal query block; checkpointing prevents retaining its score matrix."""
    scores = (query @ key.transpose(-2, -1)) / math.sqrt(head_size)
    causal_mask = key_positions[None, :] > query_positions[:, None]
    scores = scores.masked_fill(causal_mask[None, None, :, :], torch.finfo(scores.dtype).min)
    weights = F.dropout(torch.softmax(scores, dim=-1), p=dropout_probability, training=training)
    return weights @ value


class CausalSelfAttention(nn.Module):
    def __init__(self, config: dict[str, int | float]):
        super().__init__()
        n_embd, n_head = int(config["n_embd"]), int(config["n_head"])
        if n_embd % n_head:
            raise ValueError("n_embd must be divisible by n_head")
        self.n_head = n_head
        self.head_size = n_embd // n_head
        self.dropout_probability = float(config["dropout"])
        self.gradient_checkpointing = bool(config.get("gradient_checkpointing", False))
        self.qkv = nn.Linear(n_embd, 3 * n_embd, bias=True)
        self.out = nn.Linear(n_embd, n_embd, bias=True)
        self.dropout = nn.Dropout(self.dropout_probability)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, steps, width = x.shape
        q, k, v = self.qkv(x).split(width, dim=-1)
        q = q.view(batch_size, steps, self.n_head, self.head_size).transpose(1, 2)
        k = k.view(batch_size, steps, self.n_head, self.head_size).transpose(1, 2)
        v = v.view(batch_size, steps, self.n_head, self.head_size).transpose(1, 2)
        key_positions = torch.arange(steps, device=x.device)
        chunk_outputs = []
        for start in range(0, steps, 128):
            end = min(steps, start + 128)
            query_positions = torch.arange(start, end, device=x.device)
            query = q[:, :, start:end, :]
            args = (query, k, v, key_positions, query_positions, self.head_size,
                    self.dropout_probability, self.training)
            if self.training and self.gradient_checkpointing and query.requires_grad:
                # Each chunk recomputes its attention matrix during backward, so
                # the 4096-token sequence does not retain all chunk matrices at once.
                chunk = checkpoint(_causal_attention_query_chunk, *args, use_reentrant=False)
            else:
                chunk = _causal_attention_query_chunk(*args)
            chunk_outputs.append(chunk)
        output = torch.cat(chunk_outputs, dim=2).transpose(1, 2).contiguous().view(batch_size, steps, width)
        return self.dropout(self.out(output))


class TransformerBlock(nn.Module):
    def __init__(self, config: dict[str, int | float]):
        super().__init__()
        n_embd = int(config["n_embd"])
        self.ln1 = nn.LayerNorm(n_embd)
        self.attention = CausalSelfAttention(config)
        self.ln2 = nn.LayerNorm(n_embd)
        self.feed_forward = nn.Sequential(
            nn.Linear(n_embd, 4 * n_embd),
            nn.GELU(),
            nn.Linear(4 * n_embd, n_embd),
            nn.Dropout(float(config["dropout"])),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attention(self.ln1(x))
        return x + self.feed_forward(self.ln2(x))


class FrossTransformer(nn.Module):
    """Decoder-only autoregressive Transformer with a tied token-embedding/output matrix."""

    def __init__(self, vocab_size: int, config: dict[str, int | float] | None = None):
        super().__init__()
        self.config = {**DEFAULT_CONFIG, **(config or {})}
        self.vocab_size = int(vocab_size)
        n_embd = int(self.config["n_embd"])
        self.token_embedding = nn.Embedding(self.vocab_size, n_embd)
        self.position_embedding = nn.Embedding(int(self.config["block_size"]), n_embd)
        self.dropout = nn.Dropout(float(self.config["dropout"]))
        self.blocks = nn.Sequential(*[
            TransformerBlock(self.config) for _ in range(int(self.config["n_layer"]))
        ])
        self.final_norm = nn.LayerNorm(n_embd)
        self.language_head = nn.Linear(n_embd, self.vocab_size, bias=False)
        self.language_head.weight = self.token_embedding.weight
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(module: nn.Module) -> None:
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, token_ids: torch.Tensor) -> torch.Tensor:
        _, steps = token_ids.shape
        if steps > int(self.config["block_size"]):
            token_ids = token_ids[:, -int(self.config["block_size"]):]
            steps = token_ids.shape[1]
        positions = torch.arange(steps, device=token_ids.device)
        x = self.token_embedding(token_ids) + self.position_embedding(positions)[None, :, :]
        x = self.dropout(x)
        for block in self.blocks:
            if self.training and bool(self.config.get("gradient_checkpointing", False)) and x.requires_grad:
                x = checkpoint(block, x, use_reentrant=False)
            else:
                x = block(x)
        x = self.final_norm(x)
        return self.language_head(x)


def initialize_model_from_checkpoint(
    model: FrossTransformer,
    checkpoint_path: str | Path,
) -> dict[str, Any]:
    """Transfer compatible decoder layers from a Brain 1.4 or 1.6 checkpoint.

    Token embeddings are never copied because the target SentencePiece vocabulary
    has newly trained token IDs. A larger target may add decoder layers; common
    layers, final normalization and overlapping positional embeddings are reused.
    """
    source = Path(checkpoint_path)
    if not source.is_file():
        raise FileNotFoundError(f"Initialization checkpoint not found: {source}")
    checkpoint = torch.load(source, map_location="cpu", weights_only=True)
    if not isinstance(checkpoint, dict):
        raise ValueError("Initialization file is not a FROSS checkpoint.")

    source_version = checkpoint.get("version")
    if source_version not in {"FROSS Transformer 1.4", VERSION}:
        raise ValueError("Warm-start source must be FROSS Transformer 1.4 or 1.6; got "
                         + repr(source_version) + ".")
    source_format = int(checkpoint.get("format_version", 0))
    supported_formats = {1, 2} if source_version == "FROSS Transformer 1.4" else {3}
    if source_format not in supported_formats:
        raise ValueError("Unsupported source checkpoint format for " + str(source_version) + ".")

    source_config = checkpoint.get("config")
    source_state = checkpoint.get("state_dict")
    if not isinstance(source_config, dict) or not isinstance(source_state, dict):
        raise ValueError("Source checkpoint is missing model configuration or weights.")
    if checkpoint.get("inference_quantization") == "int8-rowwise-v1":
        source_state = _dequantize_inference_state_dict(source_state)

    for field in ("n_embd", "n_head"):
        if int(source_config.get(field, -1)) != int(model.config[field]):
            raise ValueError("Source and target architecture mismatch for " + field + ": "
                             + str(source_config.get(field)) + " vs " + str(model.config[field]) + ".")
    source_layers = int(source_config.get("n_layer", 0))
    target_layers = int(model.config["n_layer"])
    if source_layers < 1 or source_layers > target_layers:
        raise ValueError("Target model must have at least as many decoder layers as the source.")

    target_state = model.state_dict()
    transferable = []
    for name in target_state:
        if name.startswith("final_norm."):
            transferable.append(name)
        elif name.startswith("blocks."):
            try:
                layer_index = int(name.split(".", 2)[1])
            except (IndexError, ValueError):
                continue
            if layer_index < source_layers:
                transferable.append(name)
    if not transferable:
        raise ValueError("No compatible Transformer block weights were found.")

    copied_parameters = 0
    copied_tensors = 0
    for name in transferable:
        source_tensor = source_state.get(name)
        target_tensor = target_state[name]
        if not torch.is_tensor(source_tensor) or tuple(source_tensor.shape) != tuple(target_tensor.shape):
            raise ValueError("Source tensor is missing or has an incompatible shape: " + name)
        target_tensor.copy_(source_tensor.to(device=target_tensor.device, dtype=target_tensor.dtype))
        copied_parameters += target_tensor.numel()
        copied_tensors += 1

    source_positions = source_state.get("position_embedding.weight")
    target_positions = target_state.get("position_embedding.weight")
    if (
        not torch.is_tensor(source_positions)
        or not torch.is_tensor(target_positions)
        or source_positions.ndim != 2
        or target_positions.ndim != 2
        or source_positions.shape[1] != target_positions.shape[1]
    ):
        raise ValueError("Source positional embeddings are missing or incompatible.")
    copied_positions = min(source_positions.shape[0], target_positions.shape[0])
    target_positions[:copied_positions].copy_(
        source_positions[:copied_positions].to(device=target_positions.device, dtype=target_positions.dtype)
    )
    copied_parameters += copied_positions * target_positions.shape[1]
    copied_tensors += 1
    model.load_state_dict(target_state, strict=True)

    source_metrics = checkpoint.get("metrics", {})
    if not isinstance(source_metrics, dict):
        source_metrics = {}
    return {
        "source_version": source_version,
        "source_checkpoint": str(source),
        "source_training_steps": int(source_metrics.get("training_steps", 0)),
        "source_vocab_size": int(source_metrics.get("vocab_size", 0)),
        "source_context_size": int(source_config.get("block_size", 0)),
        "source_layers": source_layers,
        "target_layers": target_layers,
        "new_decoder_layers": target_layers - source_layers,
        "transfer_strategy": "compatible_decoder_blocks_final_norm_and_overlapping_positions",
        "transferred_tensors": copied_tensors,
        "transferred_parameters": copied_parameters,
        "copied_position_rows": copied_positions,
        "token_embeddings_reinitialized": True,
        "target_tokenizer": "sentencepiece-unigram",
    }




def _load_corpus(path: str | Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    corpus_path = Path(path)
    if not corpus_path.exists():
        raise FileNotFoundError(f"Training corpus not found: {corpus_path}")
    for line_number, line in enumerate(corpus_path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON at {corpus_path}:{line_number}") from exc
        if not isinstance(row, dict):
            continue
        user = str(row.get("user", "")).strip()
        assistant = str(row.get("assistant", "")).strip()
        if not user or not assistant:
            continue
        # Optional dialogue history teaches the model how to use follow-ups and corrections.
        history: list[dict[str, str]] = []
        raw_history = row.get("history", [])
        if isinstance(raw_history, list):
            for turn in raw_history[-8:]:
                if not isinstance(turn, dict):
                    continue
                content = " ".join(str(turn.get("content", "")).split()).strip()
                if not content:
                    continue
                role = "assistant" if str(turn.get("role", "")).lower() in {"assistant", "fross"} else "user"
                history.append({"role": role, "content": content[:700]})
        records.append({"user": user, "assistant": assistant, "history": history})
    if len(records) < 8:
        raise ValueError("The corpus must contain at least 8 user/assistant examples.")
    return records


def _format_record(record: dict[str, Any]) -> str:
    # Match the same turn labels and ordering used by generate_reply().
    parts: list[str] = []
    history = record.get("history", [])
    if isinstance(history, list):
        for turn in history[-8:]:
            if not isinstance(turn, dict):
                continue
            content = " ".join(str(turn.get("content", "")).split()).strip()[:700]
            if not content:
                continue
            role = "FROSS" if str(turn.get("role", "")).lower() in {"assistant", "fross"} else "Пользователь"
            parts.append(f"{role}: {content}")
    parts.append(f"Пользователь: {str(record['user']).strip()}")
    parts.append(f"{RESPONSE_PREFIX}{str(record['assistant']).strip()}")
    return "\n".join(parts) + "\n"


def _response_strategy(message: str) -> str:
    """Give the compact model a task-specific checklist, without generating a canned reply."""
    query = " ".join(str(message or "").lower().replace("ё", "е").split()).strip()
    plain = query.translate(str.maketrans({char: " " for char in "!?.,;:()[]{}"}))
    plain = " ".join(plain.split()).strip()

    if re.fullmatch(r"(привет|приветик|здравствуй|здравствуйте|доброе утро|добрый вечер|hello|hi|спасибо|благодарю|пока|до встречи|ок|окей|ага|угу)", plain):
        return ("Тип запроса: короткая социальная реплика. Ответь естественно и кратко, "
                "не начинай случайную тему, не придумывай факты и не запускай объяснение без просьбы.")
    if re.fullmatch(r"(почему|а почему|что это значит|а если|продолжи|продолжай|не то|не так|я же сказал|я же сказала|ты не понял|ты меня не понял|я не это имел в виду|я не это имела в виду)", plain):
        return ("Тип запроса: продолжение или исправление диалога. Сначала используй последние подходящие реплики истории. "
                "Не начинай новую тему и не проси повторить уже предоставленные данные. "
                "При исправлении считай последнее уточнение главным.")
    if re.search(r"(^|[^a-zа-яё])(переведи|перевод|translate)(?=$|[^a-zа-яё])", plain):
        return ("Тип запроса: перевод. Сначала выдай точный перевод в запрошенный язык. "
                "Не добавляй разбор грамматики, аудио или дополнительные версии, если их не просили.")
    if re.search(r"(не меняй|оставь без изменений|только эту|только этот|только при наведении|не добавляй|не трогай|исправь только|переделай только)", plain):
        return ("Тип запроса: ограниченная правка. Сохрани все явно названные элементы без изменений, "
                "измени только требуемую часть и проверь результат по каждому ограничению.")
    if re.search(r"(напиши|сделай|создай|исправь|добавь|удали|переделай|сгенерируй|реализуй|код|пример кода)", plain):
        return ("Тип запроса: получить готовый результат или код. Выполни действие, а не подменяй его советом. "
                "Соблюдай указанный язык программирования, формат и ограничения. "
                "Не заявляй, что код запущен или проверен, если этого не было.")
    if re.search(r"(что такое|что значит|что означает|объясни|расскажи|почему|как работает|в чём разница|в чем разница|определи)", plain):
        return ("Тип запроса: вопрос или объяснение. Ответь на конкретный вопрос сначала; "
                "объясни незнакомые термины простыми словами и используй пример по теме. "
                "Разделяй подтверждённые сведения и предположения.")
    if re.search(r"(я сегодня|мне сегодня|я сейчас|мне сейчас|я злюсь|мне грустно|я расстроен|я расстроена|я устал|я устала)", plain):
        return ("Тип запроса: пользователь сообщает о состоянии или событии. "
                "Учитывай слова и контекст, отвечай с поддержкой, не ставь диагноз и не выдумывай причины.")
    return ("Общий контроль ответа: выдели желаемый результат, намерение, ограничения и важный контекст; "
            "выполни просьбу по формату пользователя; не выдумывай отсутствующие сведения; "
            "если данных недостаточно, обозначь пробел и задай только один действительно нужный вопрос.")


def _format_generation_prefix(message: str) -> str:
    """Build the exact response prefix seen in training examples."""
    return "Пользователь: " + str(message).strip()[:3000] + "\n" + RESPONSE_PREFIX


def _encode_stream(records: list[dict[str, Any]], tokenizer: SentencePieceTokenizer) -> list[int]:
    stream: list[int] = []
    for record in records:
        stream.append(BOS_ID)
        stream.extend(tokenizer.encode(_format_record(record)))
        stream.append(EOS_ID)
    return stream


@torch.no_grad()
def _evaluate(model: FrossTransformer, stream: list[int], block_size: int, batches: int = 2) -> float:
    if len(stream) <= block_size + 1:
        return float("nan")
    model.eval()
    values = []
    device = next(model.parameters()).device
    last_start = len(stream) - block_size - 1
    for _ in range(batches):
        starts = [random.randint(0, last_start)]
        x = torch.tensor([stream[i:i + block_size] for i in starts], dtype=torch.long, device=device)
        y = torch.tensor([stream[i + 1:i + block_size + 1] for i in starts], dtype=torch.long, device=device)
        logits = model(x)
        values.append(float(F.cross_entropy(logits.reshape(-1, model.vocab_size), y.reshape(-1))))
    model.train()
    return sum(values) / len(values)


def train_model(
    corpus_path: str | Path = DEFAULT_CORPUS,
    output_path: str | Path = DEFAULT_CHECKPOINT,
    *,
    steps: int = 25000,
    batch_size: int = 1,
    block_size: int = 4096,
    merge_count: int | None = None,
    target_vocab_size: int = 8000,
    seed: int = 1337,
    resume: bool = False,
    initialize_from: str | Path | None = None,
    schedule_steps: int | None = None,
    progress_callback: Any = None,
    stop_callback: Any = None,
    force_cpu: bool = False,
) -> dict[str, Any]:
    """Train to a cumulative step target, optionally resuming a saved optimizer state.

    The schedule_steps value is the cumulative learning-rate schedule horizon. It may be
    extended when resuming an older checkpoint; the updated schedule applies from the
    current step onward. Keep the same or a larger cumulative target when continuing.
    """
    if steps < 1 or batch_size < 1 or block_size < 32:
        raise ValueError("steps/batch_size must be positive and block_size must be at least 32")
    schedule_total = int(schedule_steps if schedule_steps is not None else steps)
    if schedule_total < steps:
        raise ValueError("schedule_steps must be greater than or equal to the cumulative --steps target")
    if merge_count is not None:
        raise ValueError("The Brain 1.6 tokenizer is SentencePiece Unigram; the legacy --merges option is not supported. Use --vocab-size.")

    target = Path(output_path)
    resume_checkpoint: dict[str, Any] | None = None
    resume_state: dict[str, Any] | None = None
    if resume:
        if not target.is_file():
            raise FileNotFoundError(f"Cannot resume: checkpoint does not exist: {target}")
        resume_checkpoint = torch.load(target, map_location="cpu", weights_only=True)
        if int(resume_checkpoint.get("format_version", 0)) != 3:
            raise ValueError(
                "This checkpoint does not include resumable optimizer state. "
                "Start a new Brain 1.6 run with the current training code first."
            )
        resume_state = resume_checkpoint.get("resume_state")
        if not isinstance(resume_state, dict):
            raise ValueError("Checkpoint is missing its resumable training state.")
        if int(resume_state.get("seed", -1)) != seed:
            raise ValueError("Resume seed differs from the saved run. Use the same --seed (default: 1337).")
        saved_schedule = int(resume_state.get("schedule_steps", -1))
        if saved_schedule < 1:
            raise ValueError("Checkpoint does not record a valid learning-rate schedule.")

    configure_runtime_threads()
    random.seed(seed)
    torch.manual_seed(seed)
    corpus_file = Path(corpus_path)
    if not corpus_file.is_file():
        raise FileNotFoundError(f"Training corpus not found: {corpus_file}")
    corpus_sha256 = hashlib.sha256(corpus_file.read_bytes()).hexdigest()
    if resume and resume_state is not None:
        if resume_state.get("corpus_sha256") != corpus_sha256:
            raise ValueError(
                "The corpus has changed since the previous stage. Restore the exact original "
                "data/fross_corpus.jsonl before resuming."
            )

    records = _load_corpus(corpus_file)
    random.shuffle(records)
    val_count = max(2, int(len(records) * 0.1))
    validation_records, train_records = records[:val_count], records[val_count:]

    if progress_callback is not None:
        prior_metrics_for_progress = (
            resume_checkpoint.get("metrics", {}) if isinstance(resume_checkpoint, dict) else {}
        )
        try:
            progress_callback({
                "phase": "loading_corpus",
                "step": int(prior_metrics_for_progress.get("training_steps", 0)),
                "target_steps": steps,
                "train_loss": prior_metrics_for_progress.get("train_loss"),
                "validation_loss": prior_metrics_for_progress.get("validation_loss"),
                "device": "cpu" if force_cpu else str(_preferred_device()),
            })
        except Exception:
            pass

    if resume and resume_checkpoint is not None:
        tokenizer = SentencePieceTokenizer(**resume_checkpoint["tokenizer"])
    else:
        try:
            tokenizer = SentencePieceTokenizer.train(
                [_format_record(row) for row in train_records],
                target_vocab_size=target_vocab_size,
                progress_callback=progress_callback,
                stop_callback=stop_callback,
            )
        except TrainingCancelled:
            prior_metrics_for_cancel = (
                resume_checkpoint.get("metrics", {}) if isinstance(resume_checkpoint, dict) else {}
            )
            prior_steps = int(prior_metrics_for_cancel.get("training_steps", 0))
            return {
                "ok": True, "version": VERSION, "output": str(target),
                **prior_metrics_for_cancel,
                "cancelled": True,
                "training_steps": prior_steps,
                "steps_this_run": 0,
                "checkpoint_preserved": target.is_file(),
            }

    if target_vocab_size >= 8000 and tokenizer.vocab_size != target_vocab_size:
        raise ValueError(
            f"SentencePiece built only {tokenizer.vocab_size}/{target_vocab_size} tokens. "
            "The training corpus is too small or repetitive for the requested vocabulary; "
            "add more diverse text examples before training Brain 1.6."
        )

    train_stream = _encode_stream(train_records, tokenizer)
    validation_stream = _encode_stream(validation_records, tokenizer)
    actual_block = min(block_size, int(DEFAULT_CONFIG["block_size"]))
    if len(train_stream) <= actual_block + 1:
        raise ValueError("Training corpus is too small for the selected context length.")

    if resume and initialize_from is not None:
        raise ValueError("Use --initialize-from only for a new run, not together with --resume.")

    initialization_metadata: dict[str, Any] | None = None
    if resume and resume_checkpoint is not None:
        saved_initialization = resume_checkpoint.get("metrics", {}).get("initialization")
        if isinstance(saved_initialization, dict):
            initialization_metadata = dict(saved_initialization)

    if resume and resume_checkpoint is not None:
        config = resume_checkpoint.get("config")
        if not isinstance(config, dict) or int(config.get("block_size", 0)) != actual_block:
            raise ValueError("The requested block size differs from the checkpoint. Use the original --block-size.")
        prior_metrics = resume_checkpoint.get("metrics", {})
        prior_vocab_target = prior_metrics.get("requested_vocab_size")
        if prior_vocab_target is not None and int(prior_vocab_target) != target_vocab_size:
            raise ValueError("The requested vocabulary size differs from the checkpoint.")
    else:
        config = {**DEFAULT_CONFIG, "block_size": actual_block}

    device = torch.device("cpu") if force_cpu else _preferred_device()
    if progress_callback is not None:
        try:
            resume_metrics = (
                resume_checkpoint.get("metrics", {})
                if isinstance(resume_checkpoint, dict) else {}
            )
            progress_callback({
                "phase": "initializing_model",
                "step": int(resume_metrics.get("training_steps", 0)),
                "target_steps": steps,
                "device": str(device),
                "vocab_size": tokenizer.vocab_size,
            })
        except Exception:
            pass
    model = FrossTransformer(tokenizer.vocab_size, config).to(device)
    if initialize_from is not None:
        initialization_metadata = initialize_model_from_checkpoint(model, initialize_from)
    model.train()
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=0.08)
    start_step = 0
    last_loss = float("nan")
    best_validation_loss = float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    best_checkpoint_step = 0
    best_train_loss = float("nan")

    if resume and resume_checkpoint is not None and resume_state is not None:
        prior_metrics = resume_checkpoint.get("metrics", {})
        start_step = int(resume_state.get("completed_steps", 0))
        if start_step < 1:
            raise ValueError("Checkpoint has an invalid completed-step count.")
        if steps <= start_step:
            raise ValueError(
                f"Checkpoint already has {start_step} steps; --steps must be a larger cumulative target."
            )
        if int(prior_metrics.get("training_steps", -1)) != start_step:
            raise ValueError("Checkpoint metrics and optimizer state have different step counts.")
        model.load_state_dict(resume_state["last_state_dict"], strict=True)
        optimizer.load_state_dict(resume_state["optimizer_state_dict"])
        random.setstate(resume_state["python_rng_state"])
        torch.set_rng_state(resume_state["torch_rng_state"].cpu())
        saved_val = prior_metrics.get("validation_loss")
        if saved_val is not None and math.isfinite(float(saved_val)):
            best_validation_loss = float(saved_val)
        best_checkpoint_step = int(prior_metrics.get("best_checkpoint_step", start_step))
        saved_train_loss = prior_metrics.get("train_loss")
        if saved_train_loss is not None:
            best_train_loss = float(saved_train_loss)
        best_state = {
            name: value.detach().cpu().clone()
            for name, value in resume_checkpoint["state_dict"].items()
        }

    if progress_callback is not None:
        try:
            progress_callback({
                "phase": "training",
                "step": start_step,
                "target_steps": steps,
                "train_loss": best_train_loss if math.isfinite(best_train_loss) else None,
                "validation_loss": best_validation_loss if math.isfinite(best_validation_loss) else None,
                "best_checkpoint_step": best_checkpoint_step,
                "device": str(device),
                "vocab_size": tokenizer.vocab_size,
            })
        except Exception:
            pass

    last_start = len(train_stream) - actual_block - 1
    evaluation_interval = max(50, min(300, schedule_total // 8))
    completed_steps = start_step
    was_cancelled = False
    for step in range(start_step, steps):
        if stop_callback is not None and stop_callback():
            was_cancelled = True
            break
        starts = [random.randint(0, last_start) for _ in range(batch_size)]
        x = torch.tensor([train_stream[i:i + actual_block] for i in starts], dtype=torch.long, device=device)
        y = torch.tensor([train_stream[i + 1:i + actual_block + 1] for i in starts], dtype=torch.long, device=device)
        optimizer.zero_grad(set_to_none=True)
        logits = model(x)
        loss = F.cross_entropy(logits.reshape(-1, tokenizer.vocab_size), y.reshape(-1))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        learning_rate = 3e-4 * (1.0 - 0.65 * (step / max(1, schedule_total - 1)))
        for group in optimizer.param_groups:
            group["lr"] = learning_rate
        optimizer.step()
        last_loss = float(loss.detach())
        completed_steps = step + 1
        is_eval_step = (step + 1) % evaluation_interval == 0 or step + 1 == steps
        if is_eval_step:
            candidate_validation_loss = _evaluate(model, validation_stream, actual_block)
            if math.isfinite(candidate_validation_loss) and candidate_validation_loss < best_validation_loss:
                best_validation_loss = candidate_validation_loss
                best_checkpoint_step = step + 1
                best_train_loss = last_loss
                best_state = {
                    name: value.detach().cpu().clone()
                    for name, value in model.state_dict().items()
                }
        if progress_callback is not None:
            try:
                progress_callback({
                    "phase": "training",
                    "step": step + 1,
                    "target_steps": steps,
                    "train_loss": last_loss,
                    "validation_loss": best_validation_loss if math.isfinite(best_validation_loss) else None,
                    "best_checkpoint_step": best_checkpoint_step,
                    "device": str(device),
                })
            except Exception:
                pass
        if (step + 1) % max(1, (steps - start_step) // 5) == 0 or step + 1 == steps:
            shown_val = (
                f"{best_validation_loss:.4f}" if math.isfinite(best_validation_loss) else "not-yet-measured"
            )
            print(
                f"step {step + 1}/{steps} · train loss {last_loss:.4f} · "
                f"best validation loss {shown_val}",
                flush=True,
            )

    if was_cancelled and completed_steps == start_step == 0:
        prior_metrics_for_cancel = (
            resume_checkpoint.get("metrics", {}) if isinstance(resume_checkpoint, dict) else {}
        )
        return {
            "ok": True, "version": VERSION, "output": str(target),
            **prior_metrics_for_cancel,
            "cancelled": True, "training_steps": 0, "steps_this_run": 0,
            "vocab_size": tokenizer.vocab_size,
            "checkpoint_preserved": target.is_file(),
        }

    # Keep the true last training state separately from the best-validation inference weights.
    last_state_dict = {
        name: value.detach().cpu().clone()
        for name, value in model.state_dict().items()
    }

    def _cpu_tree(value: Any) -> Any:
        if torch.is_tensor(value):
            return value.detach().cpu()
        if isinstance(value, dict):
            return {key: _cpu_tree(item) for key, item in value.items()}
        if isinstance(value, list):
            return [_cpu_tree(item) for item in value]
        if isinstance(value, tuple):
            return tuple(_cpu_tree(item) for item in value)
        return value

    saved_optimizer_state = _cpu_tree(optimizer.state_dict())
    saved_python_rng_state = random.getstate()
    saved_torch_rng_state = torch.get_rng_state().clone()

    if best_state is not None:
        model.load_state_dict(best_state, strict=True)
        validation_loss = best_validation_loss
        reported_train_loss = best_train_loss
    else:
        validation_loss = _evaluate(model, validation_stream, actual_block)
        reported_train_loss = last_loss
    model.eval()
    checkpoint = {
        "format_version": 3,
        "version": VERSION,
        "config": config,
        "tokenizer": tokenizer.to_dict(),
        "state_dict": _cpu_tree(model.state_dict()),
        "resume_state": {
            "last_state_dict": last_state_dict,
            "optimizer_state_dict": saved_optimizer_state,
            "python_rng_state": saved_python_rng_state,
            "torch_rng_state": saved_torch_rng_state,
            "completed_steps": completed_steps,
            "corpus_sha256": corpus_sha256,
            "seed": seed,
            "schedule_steps": schedule_total,
        },
        "metrics": {
            "train_loss": round(reported_train_loss, 5) if math.isfinite(reported_train_loss) else None,
            "validation_loss": round(validation_loss, 5) if math.isfinite(validation_loss) else None,
            "training_device": str(device),
            "training_examples": len(train_records),
            "validation_examples": len(validation_records),
            "training_steps": completed_steps,
            "steps_this_run": completed_steps - start_step,
            "cancelled": was_cancelled,
            "schedule_steps": schedule_total,
            "best_checkpoint_step": best_checkpoint_step or steps,
            "vocab_size": tokenizer.vocab_size,
            "context_size": int(config["block_size"]),
            "requested_vocab_size": target_vocab_size if merge_count is None else None,
            "vocab_target_reached": (
                tokenizer.vocab_size == target_vocab_size if merge_count is None else None
            ),
            "tokenizer_type": "sentencepiece-unigram",
            "parameters": sum(p.numel() for p in model.parameters()),
            "initialization": initialization_metadata,
            "trained_from_random_weights": initialization_metadata is None,
        },
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    backup = target.with_name(target.stem + ".pre-brain16-backup" + target.suffix)
    if target.is_file() and not backup.exists():
        shutil.copy2(target, backup)
    temporary = target.with_name(target.name + ".brain16.tmp")
    torch.save(checkpoint, temporary)
    temporary.replace(target)
    return {
        "ok": True, "version": VERSION, "output": str(target),
        **checkpoint["metrics"]
    }


def load_model(path: str | Path = DEFAULT_CHECKPOINT) -> tuple[FrossTransformer | None, SentencePieceTokenizer | None, dict[str, Any]]:
    configure_runtime_threads()
    target = Path(path)
    if not target.is_file():
        return None, None, {"loaded": False, "reason": "checkpoint-missing", "path": str(target)}
    try:
        checkpoint = torch.load(target, map_location="cpu", weights_only=True)
        if int(checkpoint.get("format_version", 0)) != 3:
            raise ValueError("Checkpoint is not in the FROSS Brain 1.6 SentencePiece format.")
        if checkpoint.get("version") not in {VERSION, "FROSS Transformer 1.5"}:
            raise ValueError("Checkpoint version is incompatible with this FROSS Brain.")
        tokenizer = SentencePieceTokenizer(**checkpoint["tokenizer"])
        config = checkpoint["config"]
        model = FrossTransformer(tokenizer.vocab_size, config)
        state_dict = checkpoint["state_dict"]
        if checkpoint.get("inference_quantization") == "int8-rowwise-v1":
            state_dict = _dequantize_inference_state_dict(state_dict)
        model.load_state_dict(state_dict, strict=True)
        device = _preferred_device()
        model.to(device)
        model.eval()
        return model, tokenizer, {
            "loaded": True,
            "version": checkpoint.get("version", VERSION),
            "path": str(target),
            "device": str(device),
            **checkpoint.get("metrics", {}),
        }
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, EOFError) as exc:
        return None, None, {"loaded": False, "reason": type(exc).__name__, "path": str(target)}


def export_onnx_model(
    checkpoint_path: str | Path = DEFAULT_CHECKPOINT,
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """Export the exact trained weights to a fixed-shape ONNX graph for the C++ runtime.

    The graph always receives block_size token IDs. Positions after the real sequence
    are right-padded with PAD_ID; causal attention guarantees they cannot affect the
    logits at the final real token.
    """
    model, tokenizer, status = load_model(checkpoint_path)
    if model is None or tokenizer is None:
        raise RuntimeError(f"Cannot export an unavailable model: {status}")
    target = Path(output_path) if output_path else Path(checkpoint_path).with_suffix(".onnx")
    target.parent.mkdir(parents=True, exist_ok=True)
    model = model.to("cpu").eval()
    block_size = int(model.config["block_size"])
    example = torch.full((1, block_size), PAD_ID, dtype=torch.long)
    with torch.inference_mode():
        torch.onnx.export(
            model,
            (example,),
            str(target),
            input_names=["input_ids"],
            output_names=["logits"],
            opset_version=17,
            do_constant_folding=True,
            dynamo=False,
        )
    try:
        import onnx
        graph = onnx.load(str(target))
        # Keep ONNX IR metadata on a widely supported version; this graph uses no newer IR features.
        graph.ir_version = min(int(graph.ir_version), 10)
        onnx.checker.check_model(graph)
        onnx.save(graph, str(target))
    except ImportError as exc:
        raise RuntimeError("The 'onnx' package is required to export the C++ inference graph.") from exc
    return {
        "ok": True,
        "path": str(target),
        "version": VERSION,
        "block_size": block_size,
        "vocab_size": tokenizer.vocab_size,
        "onnx_ir_version": int(graph.ir_version),
    }


def _quantize_inference_state_dict(state_dict: dict[str, torch.Tensor]) -> dict[str, Any]:
    """Compress 2-D deployment weights to row-wise int8 and small vectors to fp16."""
    packed: dict[str, Any] = {}
    for name, value in state_dict.items():
        tensor = value.detach().cpu().contiguous()
        if tensor.is_floating_point() and tensor.ndim == 2:
            scales = tensor.abs().amax(dim=1).clamp_min(1e-8) / 127.0
            quantized = torch.round(tensor / scales.unsqueeze(1)).clamp(-127, 127).to(torch.int8)
            packed[name] = {
                "__fross_quantized__": "int8-rowwise-v1",
                "values": quantized,
                "scales": scales.to(torch.float16),
            }
        elif tensor.is_floating_point():
            packed[name] = tensor.to(torch.float16)
        else:
            packed[name] = tensor
    return packed


def _dequantize_inference_state_dict(state_dict: dict[str, Any]) -> dict[str, torch.Tensor]:
    """Restore compressed deployment weights to float32 before loading the model."""
    restored: dict[str, torch.Tensor] = {}
    for name, value in state_dict.items():
        if isinstance(value, dict) and value.get("__fross_quantized__") == "int8-rowwise-v1":
            quantized = value.get("values")
            scales = value.get("scales")
            if not torch.is_tensor(quantized) or quantized.dtype != torch.int8 or not torch.is_tensor(scales):
                raise ValueError("Inference checkpoint contains an invalid quantized tensor: " + name)
            restored[name] = quantized.to(torch.float32) * scales.to(torch.float32).unsqueeze(1)
        elif torch.is_tensor(value):
            restored[name] = value.to(torch.float32) if value.is_floating_point() else value
        else:
            raise ValueError("Inference checkpoint contains an unsupported tensor entry: " + name)
    return restored


def package_inference_checkpoint(
    checkpoint_path: str | Path = DEFAULT_CHECKPOINT,
    output_path: str | Path = DEFAULT_UPLOAD_CHECKPOINT,
) -> dict[str, Any]:
    """Write a small deployment checkpoint without optimizer/RNG resume state.

    The source checkpoint remains untouched and can still be used to resume training.
    """
    source = Path(checkpoint_path)
    target = Path(output_path)
    if source.resolve() == target.resolve():
        raise ValueError("The upload package must use a different path so the resumable training checkpoint is preserved.")
    if not source.is_file():
        raise FileNotFoundError(f"Training checkpoint not found: {source}")
    checkpoint = torch.load(source, map_location="cpu", weights_only=True)
    if not isinstance(checkpoint, dict):
        raise ValueError("Training checkpoint is not a FROSS checkpoint.")
    if checkpoint.get("version") != VERSION or int(checkpoint.get("format_version", 0)) != 3:
        raise ValueError("Only a compatible FROSS Brain 1.6 checkpoint can be packaged.")
    model, tokenizer, status = load_model(source)
    if model is None or tokenizer is None:
        raise ValueError("Cannot package an invalid checkpoint: " + json.dumps(status, ensure_ascii=False))
    required = ("config", "tokenizer", "state_dict", "metrics")
    if any(key not in checkpoint for key in required):
        raise ValueError("Training checkpoint is missing required inference data.")
    compact = {
        "format_version": checkpoint["format_version"],
        "version": checkpoint["version"],
        "config": checkpoint["config"],
        "tokenizer": checkpoint["tokenizer"],
        "state_dict": _quantize_inference_state_dict(checkpoint["state_dict"]),
        "inference_quantization": "int8-rowwise-v1",
        "metrics": checkpoint["metrics"],
        "checkpoint_role": "inference",
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".tmp")
    torch.save(compact, temporary)
    temporary.replace(target)
    return {
        "ok": True,
        "version": VERSION,
        "source": str(source),
        "output": str(target),
        "size_bytes": target.stat().st_size,
        "training_checkpoint_preserved": source.resolve() != target.resolve(),
        "training_steps": int(status.get("training_steps", 0)),
        "vocab_size": tokenizer.vocab_size,
        "context_size": int(model.config["block_size"]),
        "parameters": sum(parameter.numel() for parameter in model.parameters()),
        "resume_state_included": False,
        "inference_quantization": "int8-rowwise-v1",
    }



def _expand_bare_topic(message: str) -> str:
    """Make a one-word topic fit the explanatory question style used in training."""
    original = str(message or "").strip()
    normalized = re.sub(r"[.!?]+$", "", original.lower().replace("ё", "е")).strip()
    if not normalized or len(normalized.split()) != 1:
        return original
    excluded = {
        "да", "нет", "ага", "угу", "ок", "окей", "ладно", "хорошо", "хм",
        "привет", "приветик", "здравствуй", "здравствуйте", "спасибо", "благодарю",
        "пока", "стоп", "отмена", "помоги", "помогите", "сделай", "создай",
        "напиши", "исправь", "удали", "добавь", "продолжи", "продолжай",
        "переведи", "перевод", "почему", "зачем", "как", "что", "кто", "где",
        "когда", "куда", "ты", "вы", "я", "мы", "он", "она", "они", "это",
        "можно", "нельзя", "код", "тест",
    }
    if normalized in excluded or len(normalized) > 40:
        return original
    if not re.fullmatch(r"[a-zа-яё][a-zа-яё0-9_+#.-]*", normalized):
        return original
    return f"Объясни простыми словами, что такое {original.rstrip('.,!?')}."



def _social_reply(message: str) -> str | None:
    """Handle only basic social pleasantries deterministically; real questions use the model."""
    normalized = str(message or "").lower().replace("ё", "е").strip()
    normalized = re.sub(r"[!?,.;:]+", " ", normalized)
    normalized = " ".join(normalized.split())
    normalized = re.sub(r"\s+(фросс|fross)$", "", normalized)
    if normalized in {"привет", "приветик", "здравствуй", "здравствуйте", "доброе утро", "добрый день", "добрый вечер", "hello", "hi"}:
        return "Привет! Я на связи. Что хочешь обсудить?"
    if normalized in {"спасибо", "спасибо большое", "благодарю", "thanks", "thank you"}:
        return "Пожалуйста! Чем ещё помочь?"
    if normalized in {"пока", "до встречи", "до свидания", "bye", "goodbye"}:
        return "Пока! Удачи!"
    return None


@torch.inference_mode()
def generate_reply(
    model: FrossTransformer,
    tokenizer: BPETokenizer,
    message: str,
    *,
    history: list[dict[str, Any]] | None = None,
    knowledge: list[dict[str, Any]] | None = None,
    mode: str = "normal",
    max_new_tokens: int | None = None,
    temperature: float | None = None,
    top_k: int = 12,
    native_runtime: Any = None,
) -> str:
    if not str(message).strip():
        raise ValueError("Message must not be empty.")
    social = _social_reply(message)
    if social is not None:
        return social
    deep = str(mode).lower() in {"reasoning", "deep"}

    # Keep the model input close to the exact sequence format used during training.
    # Long workflow instructions previously displaced useful user text from the
    # 500-token context window even though the model had never trained on those prompts.
    context_parts: list[str] = []
    for item in (knowledge if isinstance(knowledge, list) else [])[:2]:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title", item.get("topic", ""))).strip()[:90]
        summary = str(item.get("summary", item.get("snippet", ""))).strip()[:180]
        if title and summary:
            context_parts.append(f"Знание: {title}. {summary}")
    for item in (history if isinstance(history, list) else [])[-4:]:
        if not isinstance(item, dict):
            continue
        role = "FROSS" if item.get("role") == "assistant" else "Пользователь"
        content = " ".join(str(item.get("content", "")).split())[:240]
        if content:
            context_parts.append(f"{role}: {content}")

    block_size = int(model.config["block_size"])
    prompt_budget = max(1, block_size - 1)
    latest_prompt_tokens = tokenizer.encode(_format_generation_prefix(_expand_bare_topic(message)))
    if len(latest_prompt_tokens) > prompt_budget:
        # Preserve the beginning and ending (including the FROSS response prefix).
        prefix = tokenizer.encode("Пользователь: ")
        suffix = tokenizer.encode("\nFROSS: ")
        separator = tokenizer.encode(" … ")
        available = max(1, prompt_budget - len(prefix) - len(suffix) - len(separator))
        body = tokenizer.encode(str(message).strip())
        head_count = available // 2
        tail_count = available - head_count
        latest_prompt_tokens = prefix + body[:head_count] + separator + body[-tail_count:] + suffix
        latest_prompt_tokens = latest_prompt_tokens[-prompt_budget:]
    remaining = max(0, prompt_budget - len(latest_prompt_tokens))
    context_text = "\n".join(context_parts)
    context_tokens = tokenizer.encode(context_text + "\n") if context_text else []
    # The latest user message has priority; trim old context first.
    prompt_tokens = context_tokens[-remaining:] + latest_prompt_tokens if remaining else latest_prompt_tokens
    token_ids = ([BOS_ID] + prompt_tokens)[-block_size:]
    max_tokens = max_new_tokens if max_new_tokens is not None else MAX_GENERATION_TOKENS
    temp = float(temperature if temperature is not None else (0.30 if deep else 0.34))
    temp = max(0.1, min(1.5, temp))
    generated: list[int] = []
    recent_generated: list[int] = []
    for _ in range(max(1, min(int(max_tokens), MAX_GENERATION_TOKENS))):
        device = next(model.parameters()).device
        inputs = torch.tensor([token_ids[-block_size:]], dtype=torch.long, device=device)
        if native_runtime is None:
            logits = model(inputs)[0, -1, :].float()
        else:
            logits = torch.tensor(
                native_runtime.forward(token_ids[-block_size:]),
                dtype=torch.float32,
                device=device,
            )
        logits[PAD_ID] = float("-inf")
        logits[UNK_ID] = float("-inf")
        logits[BOS_ID] = float("-inf")
        # Avoid a zero-length answer: the first few tokens should establish a
        # continuation before EOS is allowed to end sampling.
        if len(generated) < 8:
            logits[EOS_ID] = float("-inf")
        logits = logits / temp
        if recent_generated:
            seen = set(recent_generated[-64:])
            for token_id in seen:
                if 4 <= token_id < logits.numel():
                    logits[token_id] -= 0.45
        if top_k > 0 and top_k < logits.numel():
            cutoff = torch.topk(logits, top_k).values[-1]
            logits[logits < cutoff] = float("-inf")
        probabilities = torch.softmax(logits, dim=-1)
        if not torch.isfinite(probabilities).all() or float(probabilities.sum()) <= 0:
            break
        next_id = int(torch.multinomial(probabilities, num_samples=1))
        if next_id == EOS_ID:
            break
        token_ids.append(next_id)
        generated.append(next_id)
        recent_generated.append(next_id)
        decoded = tokenizer.decode(generated)
        if "\nПользователь:" in decoded:
            decoded = decoded.split("\nПользователь:", 1)[0]
            return _clean_generated_text(decoded)
    answer = tokenizer.decode(generated).split("\nПользователь:", 1)[0]
    return _clean_generated_text(answer)


def _clean_generated_text(text: str) -> str:
    """Keep paragraph/code formatting while removing runaway blank lines."""
    answer = str(text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    while "\n\n\n" in answer:
        answer = answer.replace("\n\n\n", "\n\n")
    return answer


def main() -> int:
    parser = argparse.ArgumentParser(description=VERSION)
    parser.add_argument("command", choices=("train", "test", "generate", "export", "package"))
    parser.add_argument("--corpus", default=str(DEFAULT_CORPUS))
    parser.add_argument("--output", default=str(DEFAULT_CHECKPOINT))
    parser.add_argument("--steps", type=int, default=25000, help="Cumulative training-step target; continue the same run up to 100000.")
    parser.add_argument("--resume", action="store_true", help="Continue from the last saved training state, including AdamW and RNG states.")
    parser.add_argument("--initialize-from", default=None, help="Warm-start compatible Brain 1.6 Transformer layers from a Brain 1.4 checkpoint; token embeddings remain newly initialized.")
    parser.add_argument("--schedule-steps", type=int, default=100000, help="Total learning-rate schedule horizon. Keep this at 100000 for the Brain 1.6 website cycle.")
    parser.add_argument("--seed", type=int, default=1337, help="Training seed; it must match when resuming.")
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--block-size", type=int, default=4096)
    parser.add_argument(
        "--vocab-size", type=int, default=8000,
        help="Target SentencePiece Unigram vocabulary size; Brain 1.6 defaults to 8000 tokens.",
    )
    parser.add_argument(
        "--package-output", default=str(DEFAULT_UPLOAD_CHECKPOINT),
        help="Output path for a compact inference-only checkpoint (without optimizer state).",
    )
    parser.add_argument(
        "--merges", type=int, default=None,
        help="Legacy override: train a fixed number of BPE merges instead of targeting vocab size.",
    )
    parser.add_argument("--text", default="Объясни, как обучается нейросеть.")
    parser.add_argument("--max-new-tokens", type=int, default=None)
    parser.add_argument("--onnx-output", default=None)
    args = parser.parse_args()
    if args.command == "export":
        try:
            result = export_onnx_model(args.output, args.onnx_output)
        except Exception as exc:
            print(json.dumps({"ok": False, "error": type(exc).__name__, "message": str(exc)}, ensure_ascii=False))
            return 1
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    if args.command == "package":
        try:
            result = package_inference_checkpoint(args.output, args.package_output)
        except Exception as exc:
            print(json.dumps({"ok": False, "error": type(exc).__name__, "message": str(exc)}, ensure_ascii=False))
            return 1
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    if args.command in {"train", "test"}:
        metrics = train_model(
            args.corpus,
            args.output,
            steps=args.steps if args.command == "train" else min(args.steps, 12),
            batch_size=args.batch_size,
            block_size=args.block_size,
            merge_count=args.merges,
            target_vocab_size=args.vocab_size,
            seed=args.seed,
            resume=args.resume,
            initialize_from=args.initialize_from,
            schedule_steps=args.schedule_steps,
        )
        model, tokenizer, status = load_model(args.output)
        if model is None or tokenizer is None:
            print(json.dumps({"ok": False, "error": status}, ensure_ascii=False, indent=2))
            return 1
        sample = generate_reply(model, tokenizer, args.text, max_new_tokens=24)
        result = {**metrics, "model_loaded": True, "generation_test": bool(sample), "sample": sample}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        # Training success means the checkpoint was created and can be loaded.
        # A tiny/early model can still fail a language-generation smoke sample;
        # that must not invalidate a completed training/export build.
        if args.command == "train":
            return 0
        return 0 if sample else 1
    model, tokenizer, status = load_model(args.output)
    if model is None or tokenizer is None:
        print(json.dumps({"ok": False, "status": status}, ensure_ascii=False, indent=2))
        return 1
    print(generate_reply(model, tokenizer, args.text, max_new_tokens=args.max_new_tokens))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
